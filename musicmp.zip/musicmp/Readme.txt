'''This is python based media player. It allows a thee user to play all types of 
media - audio and video. This program supports all the codec types and has a 
special feature of lyrics extraction from any song (all audio types supported) 
dynamically and stores it as text file with the song title in this same directory.
This porgram uses two modules to extract song lyrics namely pylyrics and lyricwikia 
to extract lyrics with two methods to minimise unavailibity and unability of lyrics 
extraction. Lyrics extracted will be found in the same directory where nmp.py is run 
or where it is installed.

This project needs k-lite codec package and while installation. Therefore please
install all the extentions, that is, mp4, avi etc. from the k-lite package.
K-lite package includes codecs to open all audio and video type files'''

To use this project:-
1. Install all the pre-requisites required for this repository by typing the command in windows powershell or any terminal
   'pip install -r requirements.txt'

2. Download k-lite codec package from 'https://codecguide.com/download_k-lite_codec_pack_mega.htm'.

3. Open this media player via 'python nmp.py' by opening terminal in the same directory.
   Or a standalone apllication can be created.

   To run 'nmp.py' media player as an executable apllication install pyinstaller using
   'pip install pyinstaller' command in the terminal or poweshell window if not installed already.
   Then change the directory to the directory containing 'nmp.py' and run the command
   'pyinstaller --onefile -w nmp.py'. Installation of nmp as .exe file is completed.
   Now open the folder named 'dist' and you will find your executable media player ready to use!

   For any discrepancies regarding converting '.py' files to '.exe' files, refer 'https://datatofish.com/executable-pyinstaller/'.

4. Load all your media files into the playlist and enjoy uninterrupted media pplayback in queue desired!Libraries used:-
PyQt5:
Qt is set of cross-platform C++ libraries that implement high-level APIs for accessing 
many aspects of modern desktop and mobile systems. These include location and positioning 
services, multimedia, NFC and Bluetooth connectivity, a Chromium based web browser, as well
as traditional UI development.
PyQt5 is a comprehensive set of Python bindings for Qt v5. It is implemented as more than 35 
extension modules and enables Python to be used as an alternative application development 
language to C++ on all supported platforms including iOS and Android.
PyQt5 may also be embedded in C++ based applications to allow users of those applications to 
configure or enhance the functionality of those applications.

PyLyrics:
PyLyrics is a python module to get Lyrics of songs from lyrics.wikia.com. It has 
support for getting albums of a singer and songs from an album from which lyrics can be accessed.

tinytag:
tinytag is a library for reading music meta data of MP3, OGG, OPUS, MP4, M4A, FLAC, WMA and Wave 
files with python

pydub:
Manipulate audio with an simple and easy high level interface.
It has many functions to manipulate segments if data. In this program, it is needed to convert an 
audio type into another if needed.


lyricwikia:
LyricWikia is an online wiki-based lyrics database and encyclopedia. It used to provide full access 
to song lyrics via API, but the service has been discontinued.
This API scrapes the song web page and returns the lyrics. Please verify that your use complies with 
the LyricWikia terms of service.

ffmpeg is also needed to help audio manipulation and operation.

This project contains many classes such as videowidget, playlistmodel to define the contents, buttons 
and their functions, separately so that there is good understandability level of the code.


Example audio and lyrics files have been provided with the project package.